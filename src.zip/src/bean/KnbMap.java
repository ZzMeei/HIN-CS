package bean;

import java.util.*;
import java.io.*;

public class KnbMap implements Serializable{
    public MetaPath metaPath;
    public Map<Integer, Set<Integer>> pnbMap;
    public Map<Integer, List<Set<Integer>>> visitMap;

    public KnbMap(MetaPath metaPath, Map<Integer, Set<Integer>> pnbMap, Map<Integer, List<Set<Integer>>> visitMap) {
        this.metaPath = metaPath;
        this.pnbMap = pnbMap;
        this.visitMap = visitMap;
    }

    public MetaPath getMetaPath() {
        return metaPath;
    }

    public void setMetaPath(MetaPath metaPath) {
        this.metaPath = metaPath;
    }

    public Map<Integer, Set<Integer>> getPnbMap() {
        return pnbMap;
    }

    public void setPnbMap(Map<Integer, Set<Integer>> pnbMap) {
        this.pnbMap = pnbMap;
    }

    public Map<Integer, List<Set<Integer>>> getVisitMap() {
        return visitMap;
    }

    public void setVisitMap(Map<Integer, List<Set<Integer>>> visitMap) {
        this.visitMap = visitMap;
    }

    public KnbMap getHardCopy(){
        KnbMap knbMap = new KnbMap(new MetaPath(this.metaPath), new HashMap<Integer, Set<Integer>>(), new HashMap<Integer, List<Set<Integer>>>());
        Map<Integer, Set<Integer>> pnbMapClone = knbMap.getPnbMap();
        Map<Integer, List<Set<Integer>>> visitMapClone = knbMap.getVisitMap();

//        Iterator iterPnb = pnbMap.entrySet().iterator();
//        while (iterPnb.hasNext()){
//            Map.Entry entry = (Map.Entry) iterPnb.next();
//            Integer key = (Integer)entry.getKey();
//            Set<Integer> valPointer = (Set<Integer>)entry.getValue();
//            Set<Integer> tempSet = new HashSet<Integer>();
//            Iterator iterSet = valPointer.iterator();
//            while (iterSet.hasNext()){
//                tempSet.add((Integer) iterSet.next());
//            }
//            pnbMapClone.put(key, tempSet);
//        }
//
//        Iterator iterVisit = visitMap.entrySet().iterator();
//        while (iterVisit.hasNext()){
//            Map.Entry entry = (Map.Entry) iterVisit.next();
//            Integer key = (Integer) entry.getKey();
//            List<Set<Integer>> valPointer = (List<Set<Integer>>)entry.getValue();
//            List<Set<Integer>> tempListSet = new ArrayList<Set<Integer>>();
//            for (int i = 0; i < valPointer.size(); i++){
//                Set<Integer> tempSet = new HashSet<Integer>();
//                Iterator iterSet = valPointer.get(i).iterator();
//                while (iterSet.hasNext()){
//                    tempSet.add((Integer) iterSet.next());
//                }
//                tempListSet.add(tempSet);
//            }
//            visitMapClone.put(key, tempListSet);
//        }

        for (int vertexId : pnbMap.keySet()){
            Set<Integer> tempSet = new HashSet<Integer>();
            for (int nbId : pnbMap.get(vertexId)){
                tempSet.add(nbId);
            }
            pnbMapClone.put(vertexId, tempSet);
        }
        for (int vertexId : visitMap.keySet()){
            List<Set<Integer>> tempListSet = new ArrayList<Set<Integer>>();
            for (int i = 0; i < visitMap.get(vertexId).size(); i++){
                Set<Integer> tempSet = new HashSet<Integer>();
                for (int visitId : visitMap.get(vertexId).get(i)){
                    tempSet.add(visitId);
                }
                tempListSet.add(tempSet);
            }
            visitMapClone.put(vertexId, tempListSet);
        }
        return knbMap;
    }
}
