package index.MC;
import bean.*;
import index.*;
import tool.*;
import csh.*;

import java.util.*;

public class BuildIndexMC {
    private int graph[][] = null;
    private int vertexType[] = null;
    private int edgeType[] = null;
    private int schemaGraph[][] = null;
    private ArrayList<MetaPath> allMetaPathList = null;
    private HashMap<String, IndexNode> indexTree = null;

    public BuildIndexMC(int graph[][], int vertexType[], int edgeType[], int schemaGraph[][]){
        this.graph = graph;
        this.vertexType = vertexType;
        this.edgeType = edgeType;
        this.schemaGraph = schemaGraph;
    }

    public HashMap<String, IndexNode> buildIndex(int l, int targetType){
        this.indexTree = new HashMap<String, IndexNode>();
        // Get all single meta-paths
        MetaPathGenerater metaPathGenerater = new MetaPathGenerater(schemaGraph);
        this.allMetaPathList = metaPathGenerater.generateHalfMetaPath(l, targetType);

        MetaPath shortestMetaPath = allMetaPathList.get(0);
        indexTree.put(shortestMetaPath.toString(), new IndexNode());

        indexTree.put("MC", new IndexNode());
        System.out.println("start to build meta-path tree!");
        long t1 = System.nanoTime();
        BuildMetaPathTree(shortestMetaPath, 2);
        long t2 = System.nanoTime();
        System.out.println("Finish building meta-path tree!, cost : " + (t2-t1)/1000000000);
        System.out.println("start to build index nodes!");
        t1 = System.nanoTime();
        BuildIndexNode(shortestMetaPath);
        t2 = System.nanoTime();
        System.out.println("Finish building index nodes!, cost : " + (t2-t1)/1000000000);
        return indexTree;
    }

    public void BuildMetaPathTree(MetaPath curMetaPath, int curLength){
        curLength = curLength + 2;
        for (int i = 0; i < allMetaPathList.size(); i++){
            if (allMetaPathList.get(i).getEdge().length == curLength){
                if (curMetaPath.checkNestMetaPath(allMetaPathList.get(i))){
                    MetaPath metaPath = allMetaPathList.get(i);
                    IndexNode indexNode = new IndexNode();
                    indexTree.get(curMetaPath.toString()).addChild(metaPath);
                    indexNode.setFather(curMetaPath);
                    indexTree.put(metaPath.toString(), indexNode);
                    BuildMetaPathTree(metaPath, curLength);
                }
            }
        }
    }

    public void BuildIndexNode(MetaPath curMetaPath){
        System.out.println("Build the index node of " + curMetaPath.toString());
        // long t1 = System.nanoTime();
        CoreDecomposition coreDecomposition = new CoreDecomposition(graph, vertexType, edgeType);
        Map<Integer, Integer> reverseOrderArr = coreDecomposition.decompose(curMetaPath);
//        CoreDecompositionLowMemory coreDecompositionLowMemory = new CoreDecompositionLowMemory(graph, vertexType, edgeType);
//        Map<Integer, Integer> reverseOrderArr = coreDecompositionLowMemory.decomposeNew(curMetaPath);
        // long t2 = System.nanoTime();
        // System.out.println("The cost of time " + (t2-t1) + " for meta-path: " + curMetaPath.toString());

        ArrayList<Integer> kList = new ArrayList<Integer>();
        for (int vertexId:reverseOrderArr.keySet()){
            int k = reverseOrderArr.get(vertexId);
            if (!kList.contains(k)){
                kList.add(k);
            }
        }
        Collections.sort(kList, new Comparator<Integer>() {
            @Override
            public int compare(Integer lhs, Integer rhs){
                if (lhs > rhs){
                    return 1;
                }else{
                    return -1;
                }
            }
        });

//        String curMetaPathString = curMetaPath.toString();
//
//        Map<Integer, HashSet<Integer>> vertexFatherSetMap = new HashMap<Integer, HashSet<Integer>>();
//        while (indexTree.get(curMetaPathString).getFather() != null){
//            MetaPath metaPathF = indexTree.get(curMetaPathString).getFather();
//            for (int kF : indexTree.get(metaPathF.toString()).getMap().keySet()){
//                HashSet<Integer> vertexFatherSet = new HashSet<Integer>();
//                vertexFatherSetMap.put(kF, vertexFatherSet);
//                for (int vertexId : indexTree.get(metaPathF.toString()).getMap().get(kF)){
//                    vertexFatherSetMap.get(kF).add(vertexId);
//                }
//            }
//            curMetaPathString = metaPathF.toString();
//        }

//        for (int i = 0; i < kList.size(); i++){
//            for (int vertexId : reverseOrderArr.keySet()){
//                int k = reverseOrderArr.get(vertexId);
//                if (k >= kList.get(i)){
//                    if (vertexFatherSetMap.keySet().contains(kList.get(i))){
//                        if (!vertexFatherSetMap.get(kList.get(i)).contains(vertexId)){
//                            indexTree.get(curMetaPath.toString()).addVertex(kList.get(i), vertexId);
//                        }
//                    }
//                    else {
//                        indexTree.get(curMetaPath.toString()).addVertex(kList.get(i), vertexId);
//                    }
//                }
//            }
//        }

        for (int i = 0; i < kList.size(); i++){
            for (int vertexId : reverseOrderArr.keySet()){
                int k = reverseOrderArr.get(vertexId);
                if (k >= kList.get(i)){
                    indexTree.get(curMetaPath.toString()).addVertexNumber(kList.get(i));
                }
            }
        }
        for (MetaPath metapath: indexTree.get(curMetaPath.toString()).getChildList()){
            BuildIndexNode(metapath);
        }
    }
}
