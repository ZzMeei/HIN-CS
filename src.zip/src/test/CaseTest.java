package test;

import baseline.*;
import util.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;

public class CaseTest {
    public static void main(String[] args) {
        onlineExp();
    }

    public static void onlineExp(){
        Config config = new Config();
        int[][] schemaGraph = config.getSchema("dblp");
        DataReader dataReader = new DataReader(Config.newDblpGraph, Config.newDblpVertex, Config.newDblpEdge);

        int graph[][] = dataReader.readGraph();
        int vertexType[] = dataReader.readVertexType();
        int edgeType[] = dataReader.readEdgeType();

        HashSet<Integer> queryIdSet = new HashSet<Integer>();

//        queryIdSet.add(327324); // Jiawei Han
//        queryIdSet.add(656104); // Yizhou Sun
//        queryIdSet.add(275572); // Jeffrey Xu Yu
//        queryIdSet.add(851503); // Wenjie Zhang

        HashSet<Integer> cmIdSet = new HashSet<Integer>();

        try {
            BufferedReader stdin = new BufferedReader(new FileReader("./CaseStudyData/community.txt"));
            String line  = null;
            while ((line = stdin.readLine()) != null){
                cmIdSet.add(Integer.parseInt(line));
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        for (int vertexId : cmIdSet){
            queryIdSet.add(vertexId);
            for (int i = 0; i < graph[vertexId].length; i++){
                if (i % 2 == 0){
                    queryIdSet.add(graph[vertexId][i]);
                }
            }
        }

        queryIdSet.add(327324); // Jiawei Han
        queryIdSet.add(560728); // Jun Ni
        queryIdSet.add(851503); // Wenjie Zhang

        SmallGraph sGraph = new SmallGraph(graph , vertexType , edgeType);
        sGraph.getSmallGraph(1, 50, queryIdSet);

        ArrayList<Integer> querySet = new ArrayList<Integer>();
        querySet.add(sGraph.newVidMap.get(327324));
        querySet.add(sGraph.newVidMap.get(560728));
        querySet.add(sGraph.newVidMap.get(851503));

        BasicQuery basicQuery = new BasicQuery(sGraph.smallGraph, sGraph.smallGraphVertexType, sGraph.smallGraphEdgeType, querySet, 7, schemaGraph);
        ArrayList<Set<Integer>> result_1 = basicQuery.query(4, 1);
        if (result_1 != null){
            if (result_1.size() > 0){
                for (int j = 0; j < result_1.size(); j++){
                    System.out.println("The vertices number of community " + j + " : " + result_1.get(j).size());
                    for (int vertexId : result_1.get(j)){
//                        System.out.println(sGraph.oldVidMap.get(vertexId));
                    }
                }
            }
        }
    }
}
