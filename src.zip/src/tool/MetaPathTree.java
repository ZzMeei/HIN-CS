package tool;

import bean.*;

import java.util.*;

public class MetaPathTree {
    private HashMap<String, TreeNode> metaPathTree = null;
    private int schemaGraph[][] = null;
    private ArrayList<MetaPath> allMetaPathList = null;

    public MetaPathTree(int schemaGraph[][]){
        this.schemaGraph = schemaGraph;
    }


}
