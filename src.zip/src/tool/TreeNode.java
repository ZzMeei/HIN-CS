package tool;

import bean.MetaPath;

import java.util.ArrayList;

public class TreeNode {
    private MetaPath father = null;
    private ArrayList<MetaPath> childList = null;

    public TreeNode(){
        this.childList = new ArrayList<MetaPath>();
    }

    public MetaPath getFather() {
        return father;
    }

    public void setFather(MetaPath father) {
        this.father = father;
    }

    public ArrayList<MetaPath> getChildList() {
        return childList;
    }

    public void setChildList(ArrayList<MetaPath> childList) {
        this.childList = childList;
    }

    public void addChild(MetaPath metaPath){
        this.childList.add(metaPath);
    }
}
