package util;

import bean.*;

import java.util.*;

public class PathSim {
    private int graph[][] = null;
    private int vertexType[] = null;
    private int edgeType[] = null;
    private MetaPath metaPath = null;

    public PathSim(int graph[][], int vertexType[], int edgeType[], MetaPath metaPath) {
        this.graph = graph;
        this.vertexType = vertexType;
        this.edgeType = edgeType;
        this.metaPath = metaPath;
    }

    //compute the PathSim similarity between two vertices x and y
    public double computeSimilarity(int vertexX, int vertexY) {
        int targetType = metaPath.vertex[0];
        if(vertexType[vertexX] != targetType || vertexType[vertexY] != targetType) {
            System.out.println("PathSim: the vertex types do not match the meta-path");
            System.exit(0);
        }

        //step 1: compute the middle vertex lists and map
        List<Integer> xMidVertexList = findMidVertex(vertexX, metaPath);
        List<Integer> yMidVertexList = findMidVertex(vertexY, metaPath);
        Map<Integer, Integer> xMidVertexMap = convert(xMidVertexList);
        Map<Integer, Integer> yMidVertexMap = convert(yMidVertexList);

        //step 2: compute similarity between x and y using PathSim
        int x2y = 0, x2x = 0, y2y = 0;
        for(Map.Entry<Integer, Integer> entry:xMidVertexMap.entrySet()) {
            int xMidVertex = entry.getKey(), xMidCount = entry.getValue();
            if(yMidVertexMap.containsKey(xMidVertex)) {
                int yMidCount = yMidVertexMap.get(xMidVertex);
                x2y += xMidCount * yMidCount;
            }
        }
        for(Map.Entry<Integer, Integer> entry:xMidVertexMap.entrySet()) {
            int xMidCount = entry.getValue();
            x2x += xMidCount * xMidCount;
        }
        for(Map.Entry<Integer, Integer> entry:yMidVertexMap.entrySet()) {
            int yMidCount = entry.getValue();
            y2y += yMidCount * yMidCount;
        }

        if(x2x == 0 || y2y == 0) {
            System.out.println(vertexX + " " + vertexY);
            System.out.println(x2y + " " + x2x + " " + y2y);
            System.exit(0);
        }

        return (2.0 * x2y) / (x2x + y2y);
    }

    private List<Integer> findMidVertex(int vertexId, MetaPath metaPath){
        int pathLen = metaPath.pathLen;
        List<Integer> batchList = new ArrayList<Integer>();
        batchList.add(vertexId);
        for(int index = 0;index < pathLen / 2;index ++) {
            int targetVType = metaPath.vertex[index + 1], targetEType = metaPath.edge[index];
            List<Integer> nextBatchList = new ArrayList<Integer>();
            for(int anchorId:batchList) {
                int nbArr[] = graph[anchorId];
                for(int i = 0;i < nbArr.length;i += 2) {
                    int nbVertexID = nbArr[i], nbEdgeID = nbArr[i + 1];
                    if(targetVType == vertexType[nbVertexID] && targetEType == edgeType[nbEdgeID]) {
                        nextBatchList.add(nbVertexID);
                    }
                }
            }
            batchList = nextBatchList;
        }
        return batchList;
    }

    private Map<Integer, Integer> convert(List<Integer> list){
        Map<Integer, Integer> map = new HashMap<Integer, Integer>();//vertex -> count
        for(int id:list) {
            if(map.containsKey(id)) {
                int count = map.get(id);
                map.put(id, count + 1);
            }else {
                map.put(id, 1);
            }
        }
        return map;
    }
}
