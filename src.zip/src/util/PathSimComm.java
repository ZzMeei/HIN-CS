package util;

import bean.*;
import csh.*;

import java.util.*;

public class PathSimComm {

    private int[][] graph;
    private int[] vertexType;
    private int[] edgeType;
    private PathSim pathSim;

    public PathSimComm(int graph[][], int vertexType[], int edgeType[]){
        this.graph = graph;
        this.vertexType = vertexType;
        this.edgeType = edgeType;
    }

    public double analyze(Set<Integer> commSet, MetaPath metaPath){
        this.pathSim = new PathSim(graph, vertexType, edgeType, metaPath);
        int edgeNum = 0;
        Map<Integer, Set<Integer>> graphMap = null;
        FastBCore fastBCore = new FastBCore(graph, vertexType, edgeType);
        graphMap = fastBCore.queryGraphRestrict(metaPath, commSet);
        for (int vertexId : commSet){
            edgeNum += graphMap.get(vertexId).size();
        }
        edgeNum /= 2;

        int threshold = 1000000;
        double tmpSimSum = 0.0;
        int edgeCount = 0;
        if (edgeNum < threshold){
            for (int id : commSet){
                for (int nbId : graphMap.get(id)){
                    if (id < nbId && commSet.contains(nbId)){
                        double sim = pathSim.computeSimilarity(id, nbId);
                        tmpSimSum += sim;
                        edgeCount += 1;
                    }
                }
            }
        }else {
            Object[] vertexArr = commSet.toArray();
            Random random = new Random();
            while (edgeCount < threshold){
                int index = random.nextInt(vertexArr.length);
                int vertexId = (int) vertexArr[index];

                Object[] nbVertexArr = graphMap.get(vertexId).toArray();
                int nbIndex = random.nextInt(nbVertexArr.length);
                int nbVertexId = (int)nbVertexArr[nbIndex];

                double sim = pathSim.computeSimilarity(vertexId, nbVertexId);

                tmpSimSum += sim;
                edgeCount += 1;
            }
        }

        double avgSim = tmpSimSum / edgeCount;
        return avgSim;
    }
}
